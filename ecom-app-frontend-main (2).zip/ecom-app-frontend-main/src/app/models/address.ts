export class Address {
    street: string;
    country: string;
    city: string;
    state: string;
    zipCode: string;
}
